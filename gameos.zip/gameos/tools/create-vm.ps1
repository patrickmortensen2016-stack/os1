# Create a safe, isolated VirtualBox VM for GameOS: 2 GB RAM, boots the ISO as a virtual CD.
# No virtual hard disk is attached, and no host disks/partitions are touched.
#
# Usage:  .\tools\create-vm.ps1 -IsoPath .\output\gameos-amd64.iso
param(
    [Parameter(Mandatory = $true)][string]$IsoPath,
    [string]$VmName = "GameOS",
    [int]$MemoryMB = 2048,
    [int]$Cpus = 2
)
$ErrorActionPreference = "Stop"

$vbm = Join-Path $env:ProgramFiles "Oracle\VirtualBox\VBoxManage.exe"
if (-not (Test-Path $vbm)) { throw "VBoxManage not found at $vbm. Install VirtualBox 7.x first." }

$iso = (Resolve-Path $IsoPath).Path

& $vbm showvminfo $VmName *> $null
if ($LASTEXITCODE -eq 0) { throw "A VM named '$VmName' already exists. Choose another -VmName or delete it in VirtualBox." }

function Run { & $vbm @args; if ($LASTEXITCODE -ne 0) { throw "VBoxManage $($args -join ' ') failed" } }

Run createvm --name $VmName --ostype Debian_64 --register
Run modifyvm $VmName --memory $MemoryMB --cpus $Cpus --vram 128 `
    --graphicscontroller vmsvga --firmware bios --ioapic on `
    --nic1 nat --audio-driver default --audio-controller hda --audio-enabled on `
    --clipboard-mode bidirectional --draganddrop disabled `
    --boot1 dvd --boot2 none --boot3 none --boot4 none
Run storagectl $VmName --name SATA --add sata --controller IntelAhci
Run storageattach $VmName --storagectl SATA --port 0 --device 0 --type dvddrive --medium $iso

Write-Host "VM '$VmName' created with $MemoryMB MB RAM. Starting..." -ForegroundColor Green
Run startvm $VmName
