# GameOS

A bootable **live** ISO (Debian 12 "bookworm" + XFCE) with a dark neon gaming look.
Built with Debian `live-build`. Made for VirtualBox with **2 GB RAM**.

| Feature  | What you get |
|----------|--------------|
| Browser  | Firefox ESR |
| Terminal | Xfce Terminal |
| Files    | Thunar |
| Settings | Xfce Settings Manager, audio mixer, network editor |
| Apps     | **GameOS Hub** (searchable launcher) + SuperTux, Tux Racer, Frozen Bubble, Mines |
| Look     | Arc-Dark + Papirus-Dark, neon wallpaper, bottom dock-style panel |

Live login (auto): user `gamer`, password `live` (for `sudo`). Nothing is installed to any disk;
the session lives in RAM and resets on reboot.

## Safety model (Windows)

* The ISO is built inside a **Docker container** (or a Linux VM). Your Windows install is never modified.
* The VM has **no virtual hard disk** and no raw-disk/partition access. It boots the ISO as a virtual CD.
* `create-vm.ps1` only runs `VBoxManage createvm/modifyvm/storagectl/storageattach/startvm`.
* Host files are only touched at `.\output\` (the finished ISO). Shared folders and drag-and-drop are off.

## Quick start on Windows

1. Install **VirtualBox 7.x** and **Docker Desktop** (WSL 2 backend). Needs ~15 GB free and internet.
2. Unzip this project somewhere simple, e.g. `C:\gameos`.
3. PowerShell in that folder:
   ```powershell
   Set-ExecutionPolicy -Scope Process Bypass
   .\docker\build-docker.ps1                       # 20-60 min, produces output\gameos-amd64.iso
   .\tools\create-vm.ps1 -IsoPath .\output\gameos-amd64.iso
   ```
4. The VM "GameOS" starts with 2048 MB RAM and boots the live desktop.

### Other ways to build
* **Debian/Ubuntu VM in VirtualBox** (4 GB RAM, 25 GB disk for the *builder* VM): copy the folder to a native path like `~/gameos`, then `sudo ./build.sh`.
* **WSL2 Debian/Ubuntu**: build under `~/gameos` (not `/mnt/c`), then `sudo ./build.sh`. Copy the ISO out afterwards.

### Manual VirtualBox setup (if you skip the script)
New VM > Type Linux / Debian (64-bit) > Memory **2048 MB** > *Do not add a virtual hard disk* >
Settings: Display > Graphics Controller **VMSVGA**, Video Memory 128 MB; System > Processor 2 CPUs;
Storage > Empty optical drive > choose `gameos-amd64.iso`; Network NAT.

## Customising
* Packages: `config/package-lists/gameos.list.chroot`
* Look & panel: `config/includes.chroot_after_packages/etc/skel/.config/xfce4/...`
* Wallpaper: `.../usr/share/backgrounds/gameos/wallpaper.png` (1920x1080)
* Hub apps/games: edit `ESSENTIALS` / `GAMES` in `.../usr/local/bin/gameos-hub`
* Kernel boot options (username, locale, keyboard): `auto/config` (`--bootappend-live`)
* After editing, rebuild: `.\docker\build-docker.ps1`

## Notes & limits
* 2 GB RAM is tight with Firefox open; close tabs, and keep other VMs off. Give it 3-4 GB for comfort.
* Games here are lightweight. 3D acceleration in VirtualBox is limited; this is a "gaming-styled" desktop, not a Steam/Proton rig.
* Optional: `sudo adduser gamer vboxsf` to use VirtualBox shared folders (add one in VM settings first).
* The ISO is UEFI+BIOS bootable (hybrid), so it can also be written to a USB with a tool like Rufus, but only do that
  if you understand it will boot the live system, never install over Windows.
* This project was assembled without access to a Debian mirror, so the ISO has not been test-built by its author.
  If `lb build` stops on a package name, remove or rename that line in the package list and rebuild.
