#!/usr/bin/env bash
# Build the GameOS ISO. Run on Debian/Ubuntu (or in the provided Docker image) as root.
# Everything happens inside this folder / a chroot - nothing outside it is modified.
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"

if [ "$(id -u)" -ne 0 ]; then
    echo "Please run as root:  sudo ./build.sh" >&2
    exit 1
fi

for c in lb debootstrap mksquashfs xorriso; do
    command -v "$c" >/dev/null 2>&1 || {
        echo "Missing '$c'. Install with:" >&2
        echo "  apt-get install -y live-build debootstrap squashfs-tools xorriso syslinux syslinux-common isolinux grub-pc-bin grub-efi-amd64-bin mtools dosfstools" >&2
        exit 1
    }
done

# Building on a Windows-mounted drive (/mnt/c, VirtualBox shared folder) breaks permissions.
fstype="$(df -T . | awk 'NR==2{print $2}')"
case "$fstype" in
    9p|drvfs|fuseblk|vboxsf|ntfs|ntfs3|cifs)
        echo "Refusing to build on filesystem '$fstype'. Copy this folder to a native Linux path first" >&2
        echo "(e.g. ~/gameos) or use docker/build-docker.ps1." >&2
        exit 1 ;;
esac

# Normalise line endings in case the files passed through Windows tools.
find auto config build.sh -type f ! -name '*.png' -exec sed -i 's/\r$//' {} +
chmod +x auto/* config/hooks/live/*.hook.chroot \
         config/includes.chroot_after_packages/usr/local/bin/gameos-hub

lb clean --purge || true
lb config
lb build

mkdir -p output
iso="$(ls -1 ./*.iso 2>/dev/null | head -n1 || true)"
[ -n "$iso" ] || { echo "Build finished but no ISO found - see build.log" >&2; exit 1; }
mv "$iso" output/gameos-amd64.iso
( cd output && sha256sum gameos-amd64.iso | tee gameos-amd64.iso.sha256 )
echo "Done: $(pwd)/output/gameos-amd64.iso"
