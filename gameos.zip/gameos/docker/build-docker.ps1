# Build the GameOS ISO on Windows using Docker Desktop.
# The build runs entirely inside a throw-away Linux container. The only thing written
# on Windows is the finished ISO in .\output. Your Windows install is not modified.
#
# Usage (PowerShell, from the project folder):   .\docker\build-docker.ps1
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    throw "Docker Desktop not found. Install it from https://www.docker.com/products/docker-desktop/ (WSL 2 backend), start it, then re-run."
}

New-Item -ItemType Directory -Force -Path "$root\output" | Out-Null

docker build -t gameos-builder "$root\docker"
if ($LASTEXITCODE -ne 0) { throw "docker build failed" }

# --privileged is needed so debootstrap/chroot work inside the container.
# The project is mounted read-only and copied to the container's own filesystem to build
# (building directly on an NTFS mount fails because of permissions).
docker run --rm --privileged `
    -v "${root}:/src:ro" `
    -v "${root}\output:/out" `
    gameos-builder bash -c "cp -a /src/. /build/ && rm -rf /build/output && cd /build && ./build.sh && cp output/* /out/"
if ($LASTEXITCODE -ne 0) { throw "ISO build failed (see output above)" }

Write-Host "`nISO ready: $root\output\gameos-amd64.iso" -ForegroundColor Green
